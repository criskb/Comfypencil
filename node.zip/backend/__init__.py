"""Backend helpers for ComfyPencil."""
